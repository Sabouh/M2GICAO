Travail à faire : 
firstProjetDerivHilbertPAR.pdf (en premier)
secondProjetROI.pdf (en second)
======================
Contient des données en géométries circular Fan Beam (R=3) :
dataFB192_PIx125_SL
dataFB384_2PIx125_SL
======================
programmes fournis
fbhilbertfilter.m   % filtre de Hilbert en geometrie fan beam
hilbertfilter.m     % filtre de Hilbert en geometrie parallel 
litfbsinogramme.m   % permet de lire les fichiers de données

