#include "points.h"

PointS::PointS()
{

}

PointS::PointS(int x,int y,float somme)
{
    this->x = x;
    this->y = y;
    this->somme = somme;

}

PointS::~PointS()
{

}

