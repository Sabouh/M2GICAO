#include "noeud.h"

Noeud::Noeud(){

}

Noeud::Noeud(int etiq)
{
    this->etiq = etiq;
    this->id = NULL;
    this->rank = 0;
}



