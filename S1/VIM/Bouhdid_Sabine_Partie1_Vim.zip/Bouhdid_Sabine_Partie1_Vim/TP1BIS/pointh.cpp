#include "pointh.h"

PointH::PointH(){

}

PointH::PointH(int x,int y,QRgb pix)
{
    this->x =x;
    this->y = y;
    this->pix = pix;

}

PointH::~PointH()
{

}

