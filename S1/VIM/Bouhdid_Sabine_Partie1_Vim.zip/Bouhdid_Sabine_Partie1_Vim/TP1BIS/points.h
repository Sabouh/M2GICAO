#ifndef POINTS_H
#define POINTS_H


class PointS
{
public:
    PointS(int x,int y,float somme);
    PointS();
    ~PointS();
    int x;
    int y;
    float somme;
};

#endif // POINTS_H
