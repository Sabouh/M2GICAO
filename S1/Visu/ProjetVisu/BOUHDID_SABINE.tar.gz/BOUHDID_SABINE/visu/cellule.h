#ifndef CELLULE_H
#define CELLULE_H


class Cellule
{
public:
    Cellule();
    Cellule(float x, float y, float z, float w, int config);
    float x,y,z,w;
    int config;

//signals:

//public slots:
};

#endif // CELLULE_H
