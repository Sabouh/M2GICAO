#include "cellule.h"

Cellule::Cellule()
{


}

Cellule::Cellule(float x, float y, float z, float w,int config)
{
    this->x = x;
    this->y = y;
    this->z = z;
    this->w = w;
    this->config = config;

}

